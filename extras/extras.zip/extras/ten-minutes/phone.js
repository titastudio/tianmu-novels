/* Ten Minutes · phone · "No Signal"
   Isla holds Wei Long's phone, Sunday 18 October 2026, late, in Lima, in a small rest room on the embassy's ninth floor
   after nine hours of carrying water. His phone is still on home time: Monday, 12:40 in the afternoon.
   Canon: Ch24 (16:03 Lima; her 4:16 message "Earthquake. I’m safe at the moment. Trying to get out of the building.",
   one grey tick; received 5:16 at home; Liu; the numbers in his notebook, one crossed out, one underlined twice;
   10:41 p.m. consular team at assembly point; 2:47, 2:48, 3:12, 3:56; Ren Hao (Civil); "I love you. I’m waiting." at 4:16),
   Ch25 (the satellite phone, "Watch me.", the Vancouver voicemail he didn't need to play, item three on her fridge list:
   "My mother will ring you. Answer."), Ch26 (first leave in six years; Ren Hao pays for the only seat, loudly; the 23:55),
   Ch27 (the warrant card means nothing at the checkpoint; the list under her cheek; "I have your tea"; nine floors;
   "Are you still carrying water?"). Contacts as canon: Thank You (Paid), Ren Hao (Civil), Yu Chen (Eaten?), Sir (Retired). */
StoryEngine.start({
  kind: 'phone',
  id: 'ten-minutes',
  title: 'Ten Minutes · No Signal',
  bookUrl: '../../?novel=ten-minutes',
  battery: 17,
  dark: true,
  caption: {
    open: 'Lima. Sunday night, the eighteenth of October. Three days after the ground moved.<br><br>He came through a checkpoint where his warrant card meant nothing, and found her asleep on a list, and then carried water up nine floors for nine hours because somebody needed it.<br><br>Now he is asleep on a folding bed in the little room with the medical gloves, still in his dusty shirt, and she is sitting on the floor beside him.<br><br>For three days she didn’t know if her messages had reached him. She doesn’t know what his said back.<br><br>His phone is on his chest, rising and falling. It still says Monday. He never let it change to her time.'
  },
  clock: { start: '12:40', date: 'Monday 19 October' },
  calIcon: { wd: 'Mon', dn: '19', wdLong: 'Monday' },
  lock: { code: '0303', wall: 'img/wall-phone.jpg', hintAfter: 2, nudge: 'The terminal. Eleven minutes. The third of the third.' },
  home: {
    wall: 'img/wall-phone.jpg',
    widgets: ['world', 'sugg'],
    world: [{ city: 'Home', label: 'Today', off: 0 }, { city: 'Lima', label: '13 hours behind', off: -13 }],
    sugg: ['messages', 'notes', 'phone', 'browser'],
    apps: ['calendar', 'photos', 'clock', 'notes', 'reminders', 'weather', 'settings', 'camera'],
    dock: ['phone', 'messages', 'mail', 'browser'],
    badges: {}
  },
  stubText: { mail: 'Station. 63 unread. Leave approved.', settings: 'Date & Time: Set Automatically — Off.' },
  me: { name: 'Song Wei Long', initials: 'S' },
  contacts: [
    { name: 'Thank You (Paid)', initials: 'I', fav: true, thread: 'is', phone: '+51 1 9047 2216', notes: 'Was Thank You (Owed). Changed 3 March 2025.' },
    { name: 'Ren Hao (Civil)', initials: 'R', fav: true, thread: 'rh', phone: '6233 3200', sub: 'Thirty-second floor' },
    { name: 'Yu Chen (Eaten?)', initials: 'Y', fav: true, thread: 'yc', phone: '6181 2002' },
    { name: 'Sir (Retired)', initials: 'P', thread: 'pun', phone: '2730 1948' },
    { name: 'Liu', initials: 'L', thread: 'liu', phone: '6391 0420', sub: 'Sergeant' },
    { name: 'Next Door', initials: 'E', phone: '6115 2003' },
    { name: 'Hau', initials: 'H', phone: '2311 0001', sub: 'Front desk' },
    { name: 'Sham', initials: 'S', phone: '6391 0433' },
    { name: 'Det. Supt Chiang', initials: 'C', phone: '2311 0100' },
    { name: 'Ministry, overseas emergency desk', initials: 'M', phone: '2522 0180' },
    { name: 'Mrs. Ren', initials: 'R', phone: '+1 604 822 4410', notes: 'Her mother. Vancouver. Answer. (Item three.)' }
  ],
  clockApp: { world: [{ city: 'Home', label: 'Today, +0HRS', off: 0 }, { city: 'Lima', label: 'Today, −13HRS', off: -13 }, { city: 'Vancouver', label: 'Yesterday, −15HRS', off: -15 }], alarms: [{ time: '06:15', label: 'Alarm', days: 'Weekdays', on: false }, { time: '20:50', label: 'Ring Lima (9 a.m. hers)', days: 'Every day', on: true }] },

  messages: {
    placeholder: 'Message',
    threads: [
      { id: 'rh', name: 'Ren Hao (Civil)', initials: 'R', time: '10:31', order: 50, items: [
        { t: 'day', text: '<b>Fri 16 Oct</b> 06:02' },
        { t: 'in', text: 'I’ve seen the news. Have you heard from her?' },
        { t: 'out', text: 'No. Her last message was 4:16 p.m. Lima time. She said she was trying to leave the building.' },
        { t: 'in', text: 'Have you called the ministry?' },
        { t: 'out', text: 'Three times.' },
        { t: 'in', text: 'I’m calling everyone I can reach.' },
        { t: 'out', text: 'Don’t call the same people I call.' },
        { t: 'in', text: 'I know. Wei Long. Tell me if you hear anything.' },
        { t: 'day', text: '<b>Sat 17 Oct</b> 06:51' },
        { t: 'in', text: 'Two minutes. On a satellite phone. You’re going.' },
        { t: 'in', text: 'Don’t answer that, it isn’t a question.' },
        { t: 'day', text: '<b>Sat 17 Oct</b> 09:40' },
        { t: 'in', text: 'There is one seat left on the 23:55. I have bought it. I am paying. Do not argue with me, I am on a break from Song-Zhu and I have nothing else to spend money on.' },
        { t: 'out', text: 'Thank you.' },
        { t: 'in', text: 'Say it properly when you’ve found her.' },
        { t: 'day', text: '<b>Today</b> 10:31' },
        { t: 'in', text: 'Did you find her? Did you eat? Answer one.' }
      ] },
      { id: 'is', name: 'Thank You (Paid)', initials: 'I', color: 'linear-gradient(180deg,#9fb6d6,#5b7aa6)', time: '04:22', order: 45, items: [
        { t: 'day', text: '<b>Thu 8 Oct</b> 21:10' },
        { t: 'in', text: 'I found the best peaches.' },
        { t: 'out', text: 'You said that last week.' },
        { t: 'in', text: 'These are better.' },
        { t: 'out', text: 'Evidence?' },
        { t: 'in', img: 'img/peaches.jpg' },
        { t: 'day', text: '<b>Thu 15 Oct</b> 09:50' },
        { t: 'in', text: 'I have eaten. Don’t ask.' },
        { t: 'out', text: 'I was going to ask.' },
        { t: 'in', text: 'Evidence.' },
        { t: 'out', text: 'Insufficient.' },
        { t: 'in', text: 'You’re ridiculous.' },
        { t: 'out', text: 'You’re welcome.' },
        { t: 'day', text: '<b>Fri 16 Oct</b> 05:16' },
        { t: 'in', text: 'Earthquake. I’m safe at the moment. Trying to get out of the building.' },
        { t: 'call', text: 'Call Failed', miss: true, time: '05:45' },
        { t: 'call', text: 'Call Failed', miss: true, time: '05:46' },
        { t: 'call', text: 'Call Failed', miss: true, time: '07:15' },
        { t: 'day', text: '<b>Sat 17 Oct</b> 02:48' },
        { t: 'out', text: 'I’m here. Ring when you can.', status: 'Not Delivered' },
        { t: 'day', text: '<b>Sat 17 Oct</b> 03:12' },
        { t: 'out', text: 'I’ve spoken to the ministry. They’re accounting for the consular team.', status: 'Not Delivered' },
        { t: 'call', text: 'Call Failed', miss: true, time: '03:56' },
        { t: 'day', text: '<b>Sat 17 Oct</b> 04:16' },
        { t: 'out', text: 'I love you. I’m waiting.', status: 'Not Delivered' },
        { t: 'day', text: '<b>Sat 17 Oct</b> 08:02' },
        { t: 'in', text: 'I’m still in the shelter. I’m safe. We’re working the list. I wish you were here.' },
        { t: 'out', text: 'So do I. I’m working on it.' },
        { t: 'day', text: '<b>Today</b> 04:05' },
        { t: 'in', text: 'Are you still carrying water?' },
        { t: 'out', text: 'Yes.' },
        { t: 'in', text: 'How much?' },
        { t: 'out', text: 'I haven’t counted.' },
        { t: 'in', text: 'Of course you haven’t. I love you.' },
        { t: 'out', text: 'I love you too. Finish your work.' },
        { t: 'in', text: 'You’re bossy for a man who’s been carrying bottled water all afternoon.' },
        { t: 'out', text: 'I learned from you.' }
      ] },
      { id: 'liu', name: 'Liu', initials: 'L', time: 'Saturday', order: 30, items: [
        { t: 'day', text: '<b>Fri 16 Oct</b> 08:31' },
        { t: 'in', text: 'Coffee by your elbow, sir. You haven’t slept.' },
        { t: 'day', text: '<b>Sat 17 Oct</b> 07:20' },
        { t: 'in', text: 'Sir. I have your cases. All of them. Sham has the Tanner’s Row file. Go.' },
        { t: 'out', text: 'I haven’t asked.' },
        { t: 'in', text: 'No, sir. You wouldn’t. That’s why I’m telling you.' }
      ] },
      { id: 'pun', name: 'Sir (Retired)', initials: 'P', time: 'Saturday', order: 25, items: [
        { t: 'day', text: '<b>Sat 17 Oct</b> 11:05' },
        { t: 'in', text: 'Liu tells me you have taken leave. First time in six years. Good.' },
        { t: 'in', text: 'Don’t show your warrant card at their checkpoints. It means nothing there and they’ll think less of you for trying.' },
        { t: 'out', text: 'Understood, sir.' },
        { t: 'in', text: 'Carry something. Whatever they need carried. That is what you are there for.' }
      ] },
      { id: 'yc', name: 'Yu Chen (Eaten?)', initials: 'Y', time: 'Saturday', order: 20, items: [
        { t: 'day', text: '<b>Fri 16 Oct</b> 22:10' },
        { t: 'in', text: 'Ge. Have you eaten?' },
        { t: 'out', text: 'Yes.' },
        { t: 'in', text: 'You haven’t. Auntie Tsoi is coming over with soup and she says she’s not leaving until the bowl’s empty.' },
        { t: 'day', text: '<b>Sat 17 Oct</b> 19:40' },
        { t: 'in', text: 'Eliana says the ministry page has her name under “accounted for”. She refreshes it for you so you don’t have to.' },
        { t: 'in', text: 'Go, Ge. Bring her back. Or don’t. Just go.' }
      ] }
    ]
  },

  notes: {
    items: [
      { id: 'lima', group: 'Previous 7 Days', when: '17/10/2026', stamp: '17 October 2026 at 04:20', title: 'Lima',
        body: [
          'Thu 15 Oct, ~16:03 Lima. Offshore, south-west. Magnitude being revised.',
          '05:16 (ours) her message. One grey tick.',
          '05:44 the news. Liu.',
          '07:12 first casualty figure. Preliminary.',
          '~~09:30 consular building damaged~~ (wrong building. checked.)',
          '22:41 Consular team at assembly point. Not confirmed by name.',
          '**Not confirmed by name.**',
          '02:47 rang. Failed.',
          '02:48 wrote.',
          '03:12 wrote.',
          '03:56 rang. Failed.',
          '04:00 the count past three hundred.',
          '04:16 wrote.',
          '',
          'What I know: the time. The districts. The network is down. She was safe at 4:16 their time and trying to get out.',
          'What I don’t know: everything after that.',
          '',
          'The other list is on the back of a case file. Copied it here in case the file goes back to registry.'
        ] },
      { id: 'never', group: 'Previous 7 Days', when: '16/10/2026', stamp: '16 October 2026 at 23:58', title: 'Never told her',
        body: [
          'I read your consular file the week we met. It told me nothing I wanted to know.',
          '',
          'The night after the stairwell I sat in the car outside your building for an hour and didn’t ring the bell. I thought if I rang it I would never want to leave.',
          '',
          'I told you to go to Lima because you wanted to. Then I went home and stood in your kitchen and didn’t know what to do with my hands.',
          '',
          'I didn’t know I was lonely. I thought it was quiet.',
          '',
          'I have the dates of every evening the world waited ten minutes.',
          '',
          'I have never once wanted you smaller or quieter or less difficult.',
          '',
          'I would like ordinary mornings.',
          '',
          '(If they find her: say all of it. In order. Don’t leave anything out.)'
        ] },
      { id: 'tea', group: 'Previous 7 Days', when: '17/10/2026', stamp: '17 October 2026 at 21:30', title: 'Pack',
        body: ['[x] Passport', '[x] Her tea (the tin from the kitchen, ISLA’S)', '[x] Charger, two', '[x] Plasters', '[ ] Warrant card (Sir says leave it in the case)', '[x] One shirt more than I think'] }
    ]
  },

  browser: { items: [
    { day: 'Friday 16 October', time: '05:50', q: 'lima earthquake', results: [
      { site: 'World News Desk', path: 'live', title: 'Strong earthquake strikes off the coast near Lima', snip: 'Buildings damaged along the seafront. Phone networks down across the city. Figures are preliminary.' }] },
    { day: 'Friday 16 October', time: '02:20', q: 'how long are phone networks down after an earthquake', results: [
      { site: 'Disaster Response Guide', path: 'communications', title: 'Why calls fail after a big quake', snip: 'Damaged masts, lost power and everyone calling at once. Text messages often get through before calls do, sometimes hours late.' }] },
    { day: 'Saturday 17 October', time: '07:02', q: 'flights to lima today', results: [
      { site: 'Airport Information', path: 'departures', title: 'Lima: flights operating with delays', snip: 'The airport has reopened to limited traffic. Seats are very limited.' }] },
    { day: 'Saturday 17 October', time: '07:09', q: 'police warrant card valid abroad', results: [
      { site: 'Everyday Law Guide', path: 'policing', title: 'Your warrant card outside your jurisdiction', snip: 'It identifies you. It gives you no powers. Expect to be treated as a private visitor.' }] }
  ] },

  photos: { items: [
    { src: 'img/ranun.jpg', date: '3 May 2025', time: '10:12', fav: true },
    { src: 'img/runway.jpg', date: '17 October 2026', time: '23:41' }
  ] },

  phone: {
    voicemail: [{ name: 'Mrs. Ren', when: 'Saturday', len: '0:38', unheard: true, transcript: 'Wei Long, it’s Isla’s mother. We haven’t heard anything and the ministry here keeps saying they are accounting for people. I’m sorry to ring you in the night. She told us that if anything ever happened you would know before anybody, and you would tell us. Please ring us. Her father is right here.' }],
    recents: [
      { name: 'Mrs. Ren', miss: true, when: 'Saturday', kind: 'mobile', dayLabel: 'Saturday 17 October', log: [{ time: '03:00', what: 'Missed Call', miss: true }] },
      { name: 'Unknown (+870)', when: 'Saturday', kind: 'satellite', dayLabel: 'Saturday 17 October', log: [{ time: '06:40', what: 'Incoming Call · 2 min' }] },
      { name: 'Ministry, overseas emergency desk', when: 'Friday', kind: 'work', dayLabel: 'Friday 16 October', log: [{ time: '22:41', what: 'Outgoing Call · 8 min' }, { time: '14:10', what: 'Outgoing Call · 5 min' }, { time: '06:30', what: 'Outgoing Call · 11 min' }] },
      { name: 'Thank You (Paid)', miss: true, count: 7, when: 'Friday', kind: 'mobile', dayLabel: 'Friday 16 October', log: [{ time: '05:45', what: 'Call Failed', miss: true }, { time: '05:46', what: 'Call Failed', miss: true }, { time: '07:15', what: 'Call Failed', miss: true }, { time: '11:02', what: 'Call Failed', miss: true }, { time: '19:30', what: 'Call Failed', miss: true }, { time: '02:47', what: 'Call Failed', miss: true }, { time: '03:56', what: 'Call Failed', miss: true }] }
    ]
  },
  reminders: { list: 'Reminders', items: [
    { text: 'Ring her mother back', due: 'Saturday', done: true },
    { text: 'Leave form to Chiang', done: true },
    { text: 'Tell Ren Hao properly', due: 'When I’ve found her' },
    { text: 'Item three. Answer.', done: true }
  ] },
  calendar: { today: [{ title: 'Leave', time: 'All day' }], later: [{ title: 'Lima', time: 'Until she says' }] },

  beats: [
    { id: 'rh', onLock: true, target: 'thread:rh', banner: { app: 'messages', title: 'Ren Hao (Civil)', body: 'Did you find her? Did you eat? Answer one.', when: '2h ago', open: 'thread:rh' } },
    { id: 'is', target: 'thread:is', sugg: 'messages', delay: 1800 },
    { id: 'lima', target: 'note:lima', sugg: 'notes', delay: 1800 },
    { id: 'never', target: 'note:never', delay: 1200, hold: 9000 },
    { id: 'vm', target: 'voicemail', sugg: 'phone', badge: { phone: 1 }, at: '12:52', delay: 1800 },
    { id: 'liu', target: 'thread:liu', at: '12:55', unread: 'liu', time: '12:55', push: [{ t: 'day', text: '<b>Today</b> 12:55' }, { t: 'in', text: 'Sir. Sham asks whether the ten-minute sheet continues in your absence. I have told him no. Hau has closed the book until further notice.' }], banner: { app: 'messages', title: 'Liu', body: 'Sir. Sham asks whether the ten-minute sheet continues in your absence.', open: 'thread:liu' }, delay: 3000 }
  ],
  end: {
    delay: 3400, at: '12:58', capDelay: 1800,
    caption: 'She put his phone back on his chest, face down, and rested her hand over it, the way you hold someone’s hand in a hospital corridor.<br><br>In the last week of October the last missing name on her list turned up alive, spelt wrong, in a field hospital outside the city.<br><br>She never told him she had read the list. She waited for him to say it himself, in his own time, in order.'
  }
});
