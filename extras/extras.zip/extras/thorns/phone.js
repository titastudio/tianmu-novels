/* Thorns · phone · "Face Down"
   Elowen holds Zhao's phone, Thursday 20 May 2021, a little before eight.
   Canon: Ch24 (the wreath order, the Chens' armchair, the stairs at ten to midnight, Song's call at eight).
   Older texts are quoted from Ch4, Ch7, Ch9, Ch17 and Ch23. */
StoryEngine.start({
  kind: 'phone',
  id: 'thorns',
  title: 'Thorns · Face Down',
  bookUrl: '../../?novel=thorns',
  battery: 41,
  caption: {
    open: 'Thursday, the twentieth of May.<br><br>Yesterday he walked out of her shop in the middle of a sentence, and came home at ten to midnight to say sorry on the stairs.<br><br>Now the shower is running. His phone is on his side of the bed, beside the framed camellia, and it has just lit up.<br><br>She has never once looked at it. She knows the code. There is only one number he has ever said to her as if it mattered.'
  },
  clock: { start: '07:46', date: 'Thursday 20 May' },
  calIcon: { wd: 'Thu', dn: '20', wdLong: 'Thursday' },
  lock: {
    code: '0941',
    wall: 'img/wall-phone.jpg',
    hintAfter: 2,
    nudge: 'Nine forty-one. The minute at the registry.',
    notifs: []
  },
  home: {
    wall: 'img/wall-phone.jpg',
    widgets: ['notes', 'sugg'],
    sugg: ['messages', 'notes', 'browser', 'photos'],
    apps: ['calendar', 'photos', 'clock', 'weather', 'reminders', 'notes', 'camera', 'settings'],
    dock: ['phone', 'browser', 'messages', 'mail'],
    badges: { phone: 7 }
  },
  stubText: { mail: 'No new mail.', weather: '', settings: '', clock: '', camera: '' },


  me: { name: 'Zhao Zhendong', photo: 'img/av-zhao.jpg', initials: 'Z' },
  contacts: [
    { name: 'Mrs. Zhao', photo: 'img/av-elowen.jpg', initials: 'E', fav: true, thread: 'mrs', phone: '9137 2208', notes: 'Red silk. Ranunculus. Granny Yip’s lily of the valley. Cream ribbon off her own bag.\n09:41' },
    { name: 'Si', photo: 'img/av-chen-si.jpg', initials: 'S', fav: true, thread: 'si', phone: '9001 1010', phone2: '2846 4400', phone2label: 'office' },
    { name: 'Bao', initials: 'B', fav: true, thread: 'bao', phone: '6377 5120' },
    { name: 'Aurelia Chen', photo: 'img/av-aurelia.jpg', initials: 'A', phone: '9283 6115', related: 'Si (husband)' },
    { name: 'Raiden', initials: 'R', thread: 'raiden', phone: '6408 9904', related: 'brother-in-law' },
    { name: 'Lin Jian', initials: 'L', phone: '9611 3587', sub: 'Her father' },
    { name: 'Eliana', initials: 'E', phone: '5104 2203', notes: 'Cameras. Ask Raiden first.' },
    { name: 'Xiao Pan', photo: 'img/av-xiao-pan.jpg', initials: 'X', phone: '6092 7731', notes: 'FLOWER POWER.' },
    { name: 'Granny Yip', photo: 'img/av-granny-yip.jpg', initials: 'G', phone: '2730 1162', sub: 'Market, the stall by the steps', notes: 'Lilies. Pays in tangerines.' },
    { name: 'Detective Song', initials: 'S', phone: '9455 0817', sub: 'Song Wei Long' },
    { name: 'Mrs. Chiu', initials: 'C', phone: '6155 2049', sub: 'House' },
    { name: 'Mr. Wen', initials: 'W', phone: '2471 3306', sub: 'Wen Tea Estate' },
    { name: 'Old Street Locks', initials: 'O', phone: '2385 7712' }
  ],
  clockApp: { alarms: [
    { time: '06:00', label: 'Alarm', days: 'Weekdays', on: true },
    { time: '03:45', label: 'Market', days: 'Wed', on: false }
  ] },
  messages: {
    placeholder: 'iMessage',
    threads: [
      {
        id: 'si', name: 'Si', photo: 'img/av-chen-si.jpg', initials: 'S', time: '07:39', order: 30, unread: true,
        items: [
          { t: 'day', text: '<b>Sun 16 May</b> 19:20' },
          { t: 'out', text: 'Tell her happy anniversary.' },
          { t: 'in', text: 'Tell her yourself.' },
          { t: 'out', text: 'I sent flowers.' },
          { t: 'in', text: 'From whose shop?' },
          { t: 'out', text: 'Hers.' },
          { t: 'in', text: 'Then she knows.' },
          { t: 'day', text: '<b>Yesterday</b> 18:41' },
          { t: 'out', text: 'Up?' },
          { t: 'in', text: 'Door’s open.' },
          { t: 'day', text: '<b>Yesterday</b> 23:58' },
          { t: 'in', text: 'Home?' },
          { t: 'out', text: 'Yes.' },
          { t: 'in', text: 'Good.' },
          { t: 'day', text: '<b>Today</b> 07:39' },
          { t: 'in', text: 'Well?' }
        ]
      },
      {
        id: 'mrs', name: 'Mrs. Zhao', photo: 'img/av-elowen.jpg', initials: 'E', color: 'linear-gradient(180deg,#d0505f,#a1283a)', time: 'Yesterday', order: 40,
        draft: 'I was frightened.',
        items: [
          { t: 'day', text: '<b>Tue 17 Mar 2020</b> 22:48' },
          { t: 'out', text: 'Cut them?' },
          { t: 'in', text: 'Who is this?' },
          { t: 'out', text: 'Your husband.' },
          { t: 'day', text: '<b>Thu 26 Mar 2020</b> 15:12' },
          { t: 'in', text: 'Your brother’s wife came to see me.' },
          { t: 'out', text: 'Aurelia?' },
          { t: 'in', text: 'She came to gloat.' },
          { t: 'out', text: 'Did it work?' },
          { t: 'in', text: 'No. I charged her triple for flowers.' },
          { t: 'out', text: 'Good.' },
          { t: 'in', text: 'She says there’s family dinner on Sunday. And that you and Chen Si are brothers. You didn’t tell me.' },
          { t: 'out', text: 'You didn’t ask.' },
          { t: 'day', text: '<b>Fri 10 Apr 2020</b> 21:31' },
          { t: 'out', text: 'Are you with him?' },
          { t: 'in', text: 'Yes. He’s stable.' },
          { t: 'out', text: 'Good.' },
          { t: 'in', text: 'Where are you?' },
          { t: 'day', text: '<b>Mon 19 Oct 2020</b> 11:06' },
          { t: 'in', text: 'Did you buy my building?' },
          { t: 'out', text: 'Yes.' },
          { t: 'in', text: 'When?' },
          { t: 'out', text: 'August.' },
          { t: 'in', text: 'You bought the building my shop is in two months ago and didn’t tell me.' },
          { t: 'out', text: 'A hotel group had made the old owner an offer. They were going to pull the block down.' },
          { t: 'in', text: 'That isn’t an answer to what I said.' },
          { t: 'out', text: 'I should have told you.' },
          { t: 'in', text: 'A man called Fok just came in and told me to ask my husband.' },
          { t: 'out', text: 'Is he still there?' },
          { t: 'in', text: 'No. Don’t do anything.' },
          { t: 'day', text: '<b>Thu 1 Apr</b> 10:30' },
          { t: 'out', text: 'Have you eaten?' },
          { t: 'day', text: '<b>Fri 14 May</b> 13:02' },
          { t: 'in', text: 'The lemon tree’s flowering.' },
          { t: 'out', text: 'How many?' },
          { t: 'in', text: 'I’m not counting flowers, Zhendong.' },
          { t: 'out', text: 'Eleven on the side that faces the kitchen.' },
          { t: 'in', text: 'You counted from the window.' },
          { t: 'out', text: 'Yes.' },
          { t: 'day', text: '<b>Yesterday</b> 20:00' },
          { t: 'in', text: 'Are you coming home?' }
        ]
      },
      {
        id: 'bao', name: 'Bao', initials: 'B', time: 'Yesterday', order: 20,
        items: [
          { t: 'day', text: '<b>Yesterday</b> 10:52' },
          { t: 'out', text: 'Inside. All day. Every hour.' },
          { t: 'in', text: 'Yes, sir.' },
          { t: 'day', text: '<b>Yesterday</b> 11:33' },
          { t: 'in', text: 'Detective Song came. He took the card in a plastic sleeve. He says he’ll ring Madam.' },
          { t: 'day', text: '<b>Yesterday</b> 12:02' },
          { t: 'in', text: 'Madam made me tea.' },
          { t: 'day', text: '<b>Yesterday</b> 12:47' },
          { t: 'in', text: 'A woman came in for a birthday bouquet. She saw me and remembered an appointment.' },
          { t: 'out', text: 'Move the chair.' },
          { t: 'in', text: 'I’m between Madam and the door, sir.' },
          { t: 'out', text: 'Then stay.' },
          { t: 'day', text: '<b>Yesterday</b> 13:31' },
          { t: 'in', text: 'The men have the bus station and both ends of the street. Nothing on him yet.' },
          { t: 'day', text: '<b>Yesterday</b> 14:05' },
          { t: 'in', text: 'A man asked if Madam still does funeral flowers. She said yes. He didn’t buy anything.' },
          { t: 'day', text: '<b>Yesterday</b> 15:06' },
          { t: 'in', text: 'Xiao Pan’s here. He’s put his apron on and he isn’t leaving.' },
          { t: 'day', text: '<b>Yesterday</b> 16:10' },
          { t: 'out', text: 'Has she eaten?' },
          { t: 'in', text: 'No, sir.' },
          { t: 'day', text: '<b>Yesterday</b> 16:58' },
          { t: 'in', text: 'Half a bun. Xiao Pan brought it. She ate it standing up.' },
          { t: 'day', text: '<b>Yesterday</b> 18:03' },
          { t: 'in', text: 'Shutter’s down. Xiao Pan has gone home.' },
          { t: 'day', text: '<b>Yesterday</b> 18:24' },
          { t: 'in', text: 'Madam’s home. Gate locked. Dogs are out.' },
          { t: 'out', text: 'Good.' }
        ]
      },
      {
        id: 'raiden', name: 'Raiden', initials: 'R', time: 'Yesterday', order: 10,
        items: [
          { t: 'day', text: '<b>Sat 8 May</b> 16:40' },
          { t: 'in', text: 'Is my sister there? She isn’t answering. Tell her Ah Sim wants the soup pot back.' },
          { t: 'out', text: 'She’s in the glass room. I’ll tell her.' },
          { t: 'in', text: 'You won’t. You’ll bring it yourself so you don’t have to say it.' },
          { t: 'day', text: '<b>Yesterday</b> 13:22' },
          { t: 'out', text: 'Who fits proper glass. A shop front. Not the cheap kind.' },
          { t: 'in', text: 'Whose shop?' },
          { t: 'in', text: 'Oh.' },
          { t: 'in', text: 'I’ll find you someone. Does she know?' },
          { t: 'out', text: 'Not yet.' }
        ]
      }
    ]
  },

  notes: {
    widget: 'wed',
    items: [
      {
        id: 'wed', group: 'Previous 7 Days', when: 'Yesterday', stamp: '19 May 2021 at 23:40',
        body: [
          'Wednesday.',
          '9 June is a Wednesday.',
          'He knew her day.',
          '',
          'Glass. Front window and the door. Laminated, the thick kind. Raiden will find someone. Looked it up.',
          'Button under the counter. Rings Bao’s phone. ~~Not the police.~~',
          '',
          '~~Close it until we know who~~',
          '',
          'Bao in her corner is a lock on a door.',
          '',
          'She rang the detective first.',
          'She was right to.',
          '',
          'Don’t close it.',
          'Ask her.'
        ]
      },
      {
        id: 'keys', group: 'Previous 30 Days', when: '17/03/2021', stamp: '17 March 2021 at 06:41',
        body: ['Keys', 'Thirteen.', 'Fourteenth: the armory. It has no reason. That’s the reason.', 'Nine forty-one.']
      },
      {
        id: 'lemons', group: 'Previous 30 Days', when: '17/10/2020', stamp: '17 October 2020 at 22:15',
        body: ['Lemon tree', 'Five.', 'Her father touched one the way you’d touch a sleeping child.']
      }
    ]
  },

  browser: {
    items: [
      { day: 'Yesterday', time: '14:02', q: 'laminated glass shop front stop a bullet',
        results: [
          { site: 'The Glazing Advisory', path: 'security › retail', title: 'Security glazing for small shop fronts: what actually works', snip: 'Laminated security glass of 32 mm and over, fitted in a reinforced frame, is the usual choice for street-level retail. The frame matters as much as the glass…' },
          { site: 'Shopfront Handbook', path: 'guides › glass', title: 'Bullet-resistant glass ratings explained', snip: 'Ratings are tested against specific calibres. Ask the fitter which standard the panel meets and whether the door is rated to the same level as the window.' },
          { site: 'Retail Safety Forum', path: 'threads', title: 'Upgraded our front window after a threat. Here’s what we learned', snip: 'Took nine days start to finish. The shop stayed open the whole time, they did it in two halves…' }
        ] },
      { day: 'Yesterday', time: '14:19', q: 'panic button under counter alarm to phone',
        results: [
          { site: 'Home & Shop Security', path: 'products › duress', title: 'Silent duress buttons for counters', snip: 'A silent button fitted under the counter can send an alert straight to chosen phones. No siren, nothing a customer would notice.' },
          { site: 'The Small Business Guide', path: 'security', title: 'Should a panic alarm call the police or a person you trust?', snip: 'Many owners choose both: the alert goes to a named contact first and to the monitoring centre second.' }
        ] },
      { day: 'Yesterday', time: '14:44', q: 'white peonies funeral meaning',
        results: [
          { site: 'A Language of Flowers', path: 'peony', title: 'Peony: meanings by colour', snip: 'White peonies are often sent for remembrance. In some traditions they are kept for widows, or for a death that was expected.' },
          { site: 'Florist’s Notebook', path: 'sympathy', title: 'Choosing sympathy flowers', snip: 'Lilies and chrysanthemums are the classic funeral choice. White peonies are softer, and more personal.' }
        ] },
      { day: 'Yesterday', time: '14:46', q: '9 june 2021',
        results: [
          { site: 'Day Finder', path: '2021 › june', title: 'Wednesday, 9 June 2021', snip: '9 June 2021 is a Wednesday. It is day 160 of the year. There are 21 days until the end of June.' }
        ] },
      { day: 'Yesterday', time: '23:44', q: 'what to say when you were wrong',
        results: [
          { site: 'Everyday Psychology', path: 'relationships', title: 'How to apologise without making it about you', snip: 'Name what you did. Say why it hurt. Don’t explain until you’ve been asked. The word “but” cancels everything before it.' },
          { site: 'The Marriage Column', path: 'advice', title: '“I was trying to protect her.” A reader writes in', snip: 'Protection that doesn’t ask first can feel exactly like control to the person on the other end of it…' }
        ] },
      { day: 'Yesterday', time: '23:46', q: 'how to say sorry to your wife properly',
        results: [
          { site: 'Everyday Psychology', path: 'relationships', title: 'The three parts of a real apology', snip: '1. Say what you did, plainly. 2. Say you’re sorry, with nothing after it. 3. Say what you’ll do differently, and then do it.' },
          { site: 'Ask the Counsellor', path: 'q-and-a', title: 'He walked out in the middle of an argument. Is that a deal-breaker?', snip: 'Leaving is often the part people remember longest. If you left, say so first, before anything else.' },
          { site: 'The Marriage Column', path: 'advice', title: 'Why “I’m sorry” on its own is enough', snip: 'Most people over-explain. Stand still, say it, and let her answer.' }
        ] }
    ]
  },

  photos: {
    items: [
      { src: 'img/lemon.jpg', date: '17 October 2020', time: '19:12' },
      { src: 'img/glass.jpg', date: '29 October 2020', time: '16:40' },
      { src: 'img/port.jpg', date: '12 January 2021', time: '02:18' },
      { src: 'img/rain.jpg', date: '2 March 2021', time: '19:03' },
      { src: 'img/dogs.jpg', date: '3 April 2021', time: '07:05' }
    ],
    hidden: [
      { src: 'img/h-registry.jpg', date: '17 March 2020', time: '09:41' },
      { src: 'img/h-glass-room.jpg', date: '31 October 2020', time: '09:12' },
      { src: 'img/h-counter.jpg', date: '6 March 2021', time: '15:20' },
      { src: 'img/h-asleep.jpg', date: '18 March 2021', time: '05:52' },
      { src: 'img/h-dogs.jpg', date: '3 April 2021', time: '07:04' }
    ]
  },

  phone: {
    voicemail: [
      { name: 'Granny Yip', photo: 'img/av-granny-yip.jpg', when: '16/03/2021', len: '0:21', transcript: 'It’s Granny Yip. Seven o’clock tomorrow I ring her and I say you went to work and forgot. She won’t believe me. You owe me lilies.' }
    ],
    recents: [
      { name: 'Mrs. Zhao', photo: 'img/av-elowen.jpg', initials: 'E', miss: true, count: 7, when: 'Yesterday', kind: 'mobile', dayLabel: 'Yesterday',
        log: [{ time: '21:40', what: 'Missed Call', miss: true }, { time: '21:15', what: 'Missed Call', miss: true }, { time: '20:48', what: 'Missed Call', miss: true }, { time: '20:21', what: 'Missed Call', miss: true }, { time: '19:52', what: 'Missed Call', miss: true }, { time: '19:30', what: 'Missed Call', miss: true }, { time: '19:00', what: 'Missed Call', miss: true }] },
      { name: 'Raiden', when: 'Yesterday', kind: 'mobile', dayLabel: 'Yesterday', log: [{ time: '13:15', what: 'Outgoing Call · 4 min' }] },
      { name: 'Mrs. Zhao', photo: 'img/av-elowen.jpg', initials: 'E', when: 'Yesterday', kind: 'mobile', dayLabel: 'Yesterday', log: [{ time: '10:31', what: 'Incoming Call · 2 min' }] },
      { name: 'Si', photo: 'img/av-chen-si.jpg', when: 'Monday', kind: 'mobile', dayLabel: 'Monday', log: [{ time: '22:05', what: 'Incoming Call · 11 min' }] },
      { name: 'Bao', when: 'Monday', kind: 'mobile', dayLabel: 'Monday', log: [{ time: '06:12', what: 'Outgoing Call · 1 min' }] }
    ]
  },

  reminders: {
    list: 'Reminders',
    items: [
      { text: 'Bao in the car outside. Not in her corner.', due: 'Today' },
      { text: 'Raiden: glass, window and door', due: 'Today' },
      { text: 'Tap. Leave it where it is.', note: 'She said.' }
    ]
  },

  calendar: { today: [{ title: 'North quay', time: '10:00 – 12:00' }] },

  beats: [
    { id: 'si', onLock: true, target: 'thread:si', banner: { app: 'messages', title: 'Si', body: 'Well?', when: '7m ago', open: 'thread:si' } },
    { id: 'mrs', target: 'thread:mrs', sugg: 'messages', at: '07:47', delay: 1600 },
    { id: 'bao', target: 'thread:bao', at: '07:49', unread: 'bao', time: '07:49', push: [{ t: 'day', text: '<b>Today</b> 07:49' }, { t: 'in', text: 'Morning, sir. Car’s washed. Whatever you need today.' }], banner: { app: 'messages', title: 'Bao', body: 'Morning, sir. Car’s washed. Whatever you need today.', open: 'thread:bao' }, delay: 3500 },
    { id: 'note', target: 'note:wed', sugg: 'notes', at: '07:50', delay: 1800 },
    { id: 'search', target: 'browser', sugg: 'browser', at: '07:51', delay: 1800 },
    { id: 'photos', target: 'photos', sugg: 'photos', at: '07:52', delay: 1800 },
    { id: 'calls', target: 'recents', sugg: 'phone', at: '07:53', delay: 1800 },
    { id: 'remind', target: 'reminders', at: '07:55', delay: 3000, badge: { reminders: 1 }, sugg: 'reminders',
      reminderItem: { text: 'Ask her. Don’t tell her.', due: 'Today, 07:55', past: true },
      banner: { app: 'reminders', title: 'Reminders', body: 'Ask her. Don’t tell her.', open: 'app:reminders' } }
  ],
  end: {
    delay: 4200,
    at: '08:00',
    capDelay: 1800,
    caption: 'The water was still running when her own phone rang on the bed beside her.<br><br>Song Wei Long.<br><br>She turned his phone face down by the camellia and the key, exactly where it had been, and answered.<br><br>When he came out fastening his watch, he listened to all of it without interrupting. Then he said Bao would sit outside, in the car, where she could see him from the counter and nobody else could see him at all.<br><br>“Only if you say yes.”'
  }
});
