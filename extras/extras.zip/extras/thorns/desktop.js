/* Thorns · desktop · "The Fourteenth Key"
   Zhao's study computer, Monday 1 March to Wednesday 17 March 2021.
   Canon: Ch5 (thirteen keys), Ch22 (the anniversary: Granny Yip at seven, Xiao Pan sworn,
   the vase of sweet peas, ranunculus and lily of the valley, the fourteenth key, nine forty-one). */
StoryEngine.start({
  kind: 'desktop',
  id: 'thorns',
  title: 'Thorns · The Fourteenth Key',
  bookUrl: '../../?novel=thorns',
  owner: 'Zhao Zhendong',
  wall: 'img/wall-desk.jpg',
  dock: ['finder', 'mail', 'messages', 'notes', 'browser', 'calendar', 'photos'],
  calIcon: [{ wd: 'Mon', dn: '1' }, { wd: 'Thu', dn: '4' }, { wd: 'Tue', dn: '9' }, { wd: 'Fri', dn: '12' }, { wd: 'Mon', dn: '15' }, { wd: 'Wed', dn: '17' }],
  caption: {
    open: 'His study, the first of March.<br><br>In sixteen days they will have been married a year. She has thirteen keys to this house, one for every lock. There is one door she has no key to.<br><br>He has been thinking about it since Christmas.'
  },
  days: [
    { date: 'Mon 1 Mar', dn: 1, start: '22:10',
      beats: [
        { id: 'plan', target: 'note:plan', auto: true, autoDelay: 300 },
        { id: 's1', target: 'search:s1', auto: true, delay: 2200 },
        { id: 's2', target: 'search:s2', auto: true, delay: 2600 }
      ] },
    { date: 'Thu 4 Mar', dn: 4, start: '21:34', lead: 'Thursday',
      beats: [
        { id: 'lock1', target: 'mail:lock1', mailUnread: 'lock1', notify: { app: 'mail', title: 'Old Street Locks', body: 'Re: basement door, lever lock' } },
        { id: 'home', target: 'thread:mrs', unread: 'mrs', time: '21:41', at: '21:41', delay: 3200, notify: { app: 'messages', title: 'Mrs. Zhao', body: 'Are you coming down for dinner or am I eating with the dogs?' } }
      ] },
    { date: 'Tue 9 Mar', dn: 9, start: '22:47', lead: 'Tuesday',
      beats: [
        { id: 'lock2', target: 'mail:lock2', mailUnread: 'lock2', notify: { app: 'mail', title: 'Old Street Locks', body: 'Ready. One key, plain ring, no tag.' } },
        { id: 'bao', target: 'thread:bao', unread: 'bao', time: '22:58', at: '22:58', delay: 3000, notify: { app: 'messages', title: 'Bao', body: 'Madam asked where you were this afternoon, sir.' } }
      ] },
    { date: 'Fri 12 Mar', dn: 12, start: '23:06', lead: 'Friday',
      beats: [
        { id: 'xp', target: 'thread:xp', auto: true, autoDelay: 500 },
        { id: 'si', target: 'thread:si', auto: true, delay: 3500 },
        { id: 'ref', target: 'photos', delay: 2600, notify: { app: 'photos', title: 'Photos', body: '1 photo saved' } }
      ] },
    { date: 'Mon 15 Mar', dn: 15, start: '23:28', lead: 'Monday',
      beats: [
        { id: 'say', target: 'note:say', auto: true, autoDelay: 400 },
        { id: 'cal', target: 'calendar', auto: true, delay: 2600 }
      ] },
    { date: 'Wed 17 Mar', dn: 17, start: '06:38', lead: 'Wednesday. A year.',
      beats: [
        { id: 'xp2', target: 'thread:xp', unread: 'xp', time: '06:44', at: '06:44', notify: { app: 'messages', title: 'Xiao Pan', body: 'boss its today right??' } },
        { id: 'keys', target: 'note:keys', auto: true, delay: 3000 }
      ] }
  ],

  content: {
    notes: { items: [
      { id: 'old1', day: 0, date: '14/02/2021', title: 'New Year', body: ['Lin house, Thursday 11th.', 'Ah Sim: oranges, not wine.', 'Her father asked how the shop is doing. Answer properly.'] },
      { id: 'plan', day: 0, date: '22:11', stamp: '1 March 2021 at 22:11', title: '17', body: [],
        play: [['t', 'A year.'], ['p', 900], ['t', '\n\nWhat she carried: ranunculus. Granny Yip’s lily of the valley. Cream ribbon off her own bag.'], ['p', 700], ['t', '\nWhat she wore: the red. The New Year silk she’d never worn.'], ['p', 1200], ['t', '\n\nNecklace'], ['p', 900], ['d', 8], ['t', 'Not jewellery. She’d say thank you and put it in a drawer.'], ['p', 1300], ['t', '\n\nThe flowers again. All of them, taller than she is.'], ['p', 900], ['t', '\nNot from her shop. She’d know.'], ['p', 1600], ['t', '\n\nThe key.'], ['p', 1200], ['t', '\n\nWhat do people give'], ['p', 700]] },
      { id: 'say', day: 4, date: '23:29', stamp: '15 March 2021 at 23:29', title: 'What to say', body: [],
        play: [['t', 'This is the key to the armory.'], ['p', 1400], ['d', 30], ['p', 500], ['t', 'It’s yours now.'], ['p', 1300], ['d', 15], ['p', 700], ['t', 'You’ve got a key for everything that has a reason.'], ['p', 900], ['t', '\nThe gates. The shop. The plant room.'], ['p', 800], ['t', '\nThe safe room has a code because you’d need it in a hurry.'], ['p', 1300], ['t', '\nThis one doesn’t have a reason.'], ['p', 1600], ['t', '\n\nIt’s for if you just want to come in.'], ['p', 900], ['t', '\nWhen I’m down there.'], ['p', 700], ['t', '\nYou don’t have to knock. You don’t have to say why.'], ['p', 1800], ['t', '\n\nDon’t say any more than that.']] },
      { id: 'keys', day: 5, date: '06:41', stamp: '17 March 2021 at 06:41', title: 'Keys', body: [],
        play: [['t', 'Thirteen.'], ['p', 1100], ['t', '\nFourteenth: the armory. It has no reason. That’s the reason.'], ['p', 2000], ['t', '\n\nNine forty-one.']] }
    ] },

    mail: { items: [
      { id: 'm1', day: 0, from: 'Harbour Board', subject: 'Berth allocation, week 10', date: '26/02/2021', full: '26 February 2021 at 09:12', body: 'Dear Mr Zhao,\n\nPlease find attached the berth allocation for week 10. North quay berths 3 and 4 remain closed for resurfacing until Friday 12 March.\n\nRegards,\nAllocations Office' },
      { id: 'm2', day: 0, from: 'Wen Tea Estate', subject: 'The old tree', date: '22/02/2021', full: '22 February 2021 at 07:40', body: 'Mr Zhao,\n\nThe old camellia on the east slope is in flower, as you said it would be. Your wife asked me in the autumn to let her know when. I have written to her.\n\nThe weather is poor and the road is slow. Tell her not to drive up in the rain.\n\nWen' },
      { id: 'lock1', day: 1, from: 'Old Street Locks', subject: 'Re: basement door, lever lock', date: '21:33', full: 'Thursday 4 March 2021 at 21:33', body: 'Mr Zhao,\n\nI came up on Tuesday as arranged and looked at the basement door. It is an old five-lever mortice, a 1960s pattern. Nobody makes them now, which is why it has done so well.\n\nI can cut one more key from yours by hand. You asked that no record be kept and no blank left over. I do not keep records of this kind of job.\n\nYou also asked for a plain ring, silver, no tag. I have one.\n\nReady Tuesday 9th. I can bring it to you, or you can collect.\n\nOld Street Locks' },
      { id: 'lock2', day: 2, from: 'Old Street Locks', subject: 'Ready', date: '22:46', full: 'Tuesday 9 March 2021 at 22:46', body: 'Mr Zhao,\n\nOne key, cut by hand from yours this afternoon. Tested in the door while you watched. Plain silver ring, no tag. No copy made, no blank kept.\n\nThe key is heavier than the ones cut now. That is the old brass. It will outlast the door.\n\nOld Street Locks' }
    ] },

    messages: { threads: [
      { id: 'mrs', day: 0, name: 'Mrs. Zhao', photo: 'img/av-elowen.jpg', time: 'Sun', order: 40, items: [
        { t: 'day', text: '<b>Sun 28 Feb</b> 18:02' },
        { t: 'in', text: 'Mr. Wen wrote. The old tree on the east slope is flowering.' },
        { t: 'out', text: 'I told you. February and March.' },
        { t: 'in', text: 'I want to go up and see it.' },
        { t: 'out', text: 'It’s raining up there.' },
        { t: 'in', text: 'It’s always raining up there.' },
        { t: 'day', text: '<b>Thu 4 Mar</b> 21:41', beat: 'home', day: 1 },
        { t: 'in', text: 'Are you coming down for dinner or am I eating with the dogs?', day: 1 },
        { t: 'out', text: 'Coming.', day: 1, live: true, play: [['t', 'Working late. Start without'], ['p', 900], ['d', 27], ['p', 600], ['t', 'Coming.']] },
        { t: 'in', text: 'You said that twenty minutes ago.', day: 1, live: true, wait: 1800 },
        { t: 'out', text: 'Now.', day: 1, live: true, play: [['p', 400], ['t', 'Now.']] }
      ] },
      { id: 'si', day: 0, name: 'Si', photo: 'img/av-chen-si.jpg', time: 'Fri', order: 30, items: [
        { t: 'day', text: '<b>Fri 26 Feb</b> 23:40' },
        { t: 'in', text: 'Aurelia wants you both on Saturday.' },
        { t: 'out', text: 'Ask Elowen.' },
        { t: 'in', text: 'Aurelia already did. She said yes.' },
        { t: 'out', text: 'Then we’re coming.' },
        { t: 'day', text: '<b>Fri 12 Mar</b> 23:31', beat: 'si', day: 3 },
        { t: 'out', text: 'What did you give her. The first year.', day: 3, live: true, play: [['t', 'What do you give a wife'], ['p', 1100], ['d', 23], ['p', 500], ['t', 'What did you give her. The first year.']] },
        { t: 'in', text: 'She told me what she wanted.', day: 3, live: true, wait: 2600 },
        { t: 'out', text: 'And if she doesn’t tell you.', day: 3, live: true },
        { t: 'in', text: 'Then you’ve been listening or you haven’t.', day: 3, live: true, wait: 3000 },
        { t: 'in', text: 'You have. Go to bed.', day: 3, live: true, wait: 1800 }
      ] },
      { id: 'bao', day: 0, name: 'Bao', time: 'Mon', order: 20, items: [
        { t: 'day', text: '<b>Mon 1 Mar</b> 18:30' },
        { t: 'in', text: 'Madam’s home. Shop shut at six. She bought Granny Yip’s lilies again.' },
        { t: 'day', text: '<b>Tue 9 Mar</b> 22:58', beat: 'bao', day: 2 },
        { t: 'in', text: 'Madam asked where you were this afternoon, sir. I said the port.', day: 2 },
        { t: 'out', text: 'Did she believe you?', day: 2, live: true, play: [['p', 900], ['t', 'Did she believe you?']] },
        { t: 'in', text: 'No, sir.', day: 2, live: true, wait: 2200 },
        { t: 'out', text: 'Good.', day: 2, live: true, play: [['p', 1200], ['t', 'Good.']] }
      ] },
      { id: 'xp', day: 3, name: 'Xiao Pan', photo: 'img/av-xiao-pan.jpg', time: '23:07', order: 50, items: [
        { t: 'day', text: '<b>Fri 12 Mar</b> 23:07' },
        { t: 'out', text: 'Sweet peas, ranunculus and lily of the valley. White and the palest pink.', live: true },
        { t: 'out', text: 'Taller than she is. In the courtyard by the lemon tree. Wednesday the 17th, while she’s at the shop.', live: true },
        { t: 'in', text: 'from the market??', live: true, wait: 2400 },
        { t: 'in', text: 'not from our shop??', live: true, wait: 900 },
        { t: 'out', text: 'Not from her shop. She’d know.', live: true },
        { t: 'in', text: 'boss she’ll know anyway', live: true, wait: 1600 },
        { t: 'out', text: 'Granny Yip will ring her at seven and tell her I’ve forgotten.', live: true },
        { t: 'in', text: 'omg', live: true, wait: 1500 },
        { t: 'in', text: 'ok', live: true, wait: 900 },
        { t: 'in', text: 'i know nothing', live: true, wait: 1100 },
        { t: 'out', text: 'Swear.', live: true, play: [['p', 700], ['t', 'Swear.']] },
        { t: 'in', text: 'i swear on the FLOWER POWER hoodie', live: true, wait: 1700 },
        { t: 'day', text: '<b>Wed 17 Mar</b> 06:44', day: 5 },
        { t: 'in', text: 'boss its today right??', day: 5 },
        { t: 'in', text: 'market at 12. at the house by 2. madam is at the shop all day right', day: 5 },
        { t: 'out', text: 'Until six.', day: 5, live: true, play: [['p', 1000], ['t', 'Until six.']] },
        { t: 'in', text: 'ok ok ok', day: 5, live: true, wait: 1400 },
        { t: 'in', text: 'happy anniversary mr zhao', day: 5, live: true, wait: 1600 }
      ] }
    ] },

    browser: { items: [
      { id: 'old', day: 0, dayLabel: 'Saturday 27 February', time: '01:12', q: 'camellia east slope flowering time', results: [{ site: 'Garden Notes', path: 'camellia', title: 'When do old camellias flower?', snip: 'Most flower from late winter into spring, February to April, depending on the altitude and the year.' }] },
      { id: 's1', day: 0, dayLabel: 'Monday 1 March', time: '22:18', q: 'first wedding anniversary traditional gift', live: true,
        play: [['t', 'what to give your wife for'], ['p', 900], ['d', 26], ['p', 500], ['t', 'first wedding anniversary traditional gift']],
        results: [
          { site: 'Wedding Almanac', path: 'anniversaries › first', title: 'First anniversary: paper', snip: 'The traditional first anniversary gift is paper: a letter, a book, a map, tickets, a deed. Something you can hold that says where you started.' },
          { site: 'The Considerate Husband', path: 'gifts', title: 'Twelve first anniversary ideas she won’t put in a drawer', snip: 'Avoid the jewellery-box reflex. The best first-year gifts are the ones only you could have known to give.' },
          { site: 'Everyday Etiquette', path: 'marriage', title: 'Does a first anniversary need a gift at all?', snip: 'Many couples simply mark the day. Flowers like the ones from the wedding are a common, quiet choice.' }
        ] },
      { id: 's2', day: 0, dayLabel: 'Monday 1 March', time: '22:24', q: 'lily of the valley in march', live: true,
        results: [
          { site: 'The Cut Flower Grower', path: 'convallaria', title: 'Lily of the valley: forcing for early spring', snip: 'Outdoors it flowers in late spring, but growers force the crowns indoors for February and March. Ask a good market stall a week ahead.' },
          { site: 'Flower Market Guide', path: 'seasonal', title: 'What’s at the market in March', snip: 'Ranunculus are at their best, sweet peas are starting, and forced lily of the valley appears in small bunches, usually at a price.' }
        ] }
    ] },

    calendar: { year: 2021, month: 2, label: 'March', events: [
      { d: 4, text: 'North quay 10:00' },
      { d: 9, text: 'Locks 15:00', day: 1 },
      { d: 12, text: 'Berths 3 and 4 reopen' },
      { d: 17, text: 'Port review (all day)', day: 4 },
      { d: 17, text: '9:41', red: true, day: 4 },
    ] },

    files: { folders: [
      { name: 'Documents', items: [
        { name: 'North quay lease 2021.pdf', kind: 'pdf', date: '11 Jan 2021', body: ['NORTH QUAY · BERTHS 3–4', '', 'Lease renewal, five years from 1 April 2021.', 'Lessee: a company whose name does not matter here.', '', 'Signed and returned.'] },
        { name: 'House', kind: 'doc', date: '21 Mar 2020', body: ['Locks', '', 'Front. Side. Garage. Garden store. East and west wing doors. Study. Plant room (from Oct). Gate, both. Shop: hers, not mine. Safe room: code.', '', 'Thirteen keys on her ring.', '', 'Basement: mine.'] }
      ] },
      { name: 'Downloads', items: [
        { name: 'ranunculus.jpg', src: 'img/ranun.jpg', date: '12 Mar 2021', day: 3 }
      ] },
      { name: 'Trash', trash: true, items: [
        { name: 'card.rtf', kind: 'doc', date: '14 Mar 2021', day: 3, body: ['Elowen,', '', '~~A year ago you married a man you had known for fifteen days.~~', '', '~~I am not good at cards.~~', '', 'This is the fourteenth.', '', '~~It opens~~'] }
      ] }
    ] },
    photos: { items: [
      { src: 'img/lemon.jpg', day: 0, date: '17 Oct 2020', caption: '' },
      { src: 'img/glass.jpg', day: 0, date: '29 Oct 2020', caption: '' },
      { src: 'img/port.jpg', day: 0, date: '12 Jan 2021', caption: '' },
      { src: 'img/ranun.jpg', day: 3, date: '12 Mar 2021', caption: '' }
    ] }
  },
  end: {
    capDelay: 4200,
    caption: 'He went to work and asked Granny Yip to ring her at seven.<br><br>When he came home she was in the glass room with her sleeves pushed up, and she held out a flat parcel in brown paper before he could pretend any longer: a camellia from the east slope, fallen on its own, pressed and framed.<br><br>The key was in his jacket pocket the whole time.<br><br>That night at the mirror she asked him what time it had been at the registry, and he told her the minute.'
  }
});
